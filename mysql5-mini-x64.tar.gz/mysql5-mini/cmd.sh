
export LD_LIBRARY_PATH=./lib:$LD_LIBRARY_PATH

./bin/mysql  --defaults-file=./my.cnf --socket=./data/mysql.sock -h localhost -u test -ptest test

